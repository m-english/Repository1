#Michael English

library(readxl)
library(tidyverse)
library(haven)
library(sjmisc)
library(plyr)
library(caret)



Atlanta_Routes <- read_excel("Datasets/Atlanta_Routes.xlsx")
BTS <- read_excel("Datasets/BTS.xlsx")
REF <- read_excel("Datasets/ACFTREF.xlsx")
Trunk <- read_excel("Datasets/Trunk.xlsx")
str(Trunk)
summary(Trunk)


###
str(Atlanta_Routes)
summary(Atlanta_Routes)


BTS <- select(BTS, -c(YEAR,ORIGIN_CITY_NAME))

###

Atlanta_Routes <- select(Atlanta_Routes, -c(YEAR,MONTH))


str(BTS)
str(Atlanta_Routes)



BTS <- subset(BTS, Destination == "New York, NY" | Destination == "Fort Lauderdale, FL"| Destination == "Orlando, FL"| Destination == "Tampa, FL"| Destination ==  "Los Angeles, CA"| Destination == "Boston, MA")
#Atlanta_Routes <- subset(Atlanta_Routes, CARRIER_NAME == "Delta Air Lines Inc." | CARRIER_NAME == "Southwest Airlines Co.")

Atlanta_Routes <- subset(Atlanta_Routes, Destination == "New York, NY" | Destination == "Fort Lauderdale, FL"| Destination == "Orlando, FL"| Destination == "Tampa, FL"| Destination ==  "Los Angeles, CA"| Destination == "Boston, MA")



BTS_PLOT <- ggplot(BTS, aes(x = DATE, y = Destination, color = Destination)) + geom_jitter(alpha = 0.6) + geom_smooth(size = 0.01) + 
  theme(axis.text.x = element_text(angle=65, vjust=0.6))

BTS_PLOT

ARoutes <- ggplot(Atlanta_Routes, aes(CARRIER_NAME)) + geom_bar(aes(fill=Destination), width = 0.6) + 
theme(axis.text.x = element_text(angle=65, vjust=0.6)) + 
labs(title="Distribution of Flights by Airline")

ARoutes


LASum <-sum(BTS$Destination == "Los Angeles, CA")
str(LASum)
#
FLSum <-sum(BTS$Destination == "Fort Lauderdale, FL")
str(FLSum)
#
ORSum <-sum(BTS$Destination == "Orlando, FL")
str(ORSum)
#
TASum <-sum(BTS$Destination == "Tampa, FL")
str(TASum)
#
NYSum <-sum(BTS$Destination == "New York, NY")
str(NYSum)
#
BOSum <-sum(BTS$Destination == "Boston, MA")
str(BOSum)
#

FpCity <- c(LASum, FLSum, ORSum, TASum, NYSum, BOSum)
str(FpCity)



#Exploratory Data Analysis
dim(BTS)

sapply(BTS, class)

summary(BTS)
summary(Atlanta_Routes)
 
summary(validation_index)

####

FpCity <- as.numeric(as.character(Trunk$FpCity))

# load libraries
library(caret)
# load data
#data(BTS)
# prepare resampling method
control <- trainControl(method="cv", number=5)
set.seed(7)
fit <- train(PASSENGERS ~ FpCity, data=Trunk, method="lm", metric="RMSE", trControl=control)
# display results
print(fit)
####

dim(BTS)

sapply(Trunk, class)

#TEsting Data: 20%, Training 80% training.
# create a list of 20% of the rows in the original dataset we can use for training
validation_index <- createDataPartition(BTS$TAIL_NUM, p=0.80, list=FALSE)
# select 20% of the data for validation
validation <- BTS[-validation_index,]
# use the remaining 80% of data to training and testing the models
BTS <- BTS[validation_index,]


Trunk$FpCity <- as.numeric(as.character(Trunk$FpCity))
modellr <- lm(PASSENGERS ~ FpCity, data = Trunk)
summary(modellr)

str(Trunk)
summary(Trunk)


